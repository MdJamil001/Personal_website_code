document.addEventListener('DOMContentLoaded',function(){
  var t=document.querySelector('.menu-toggle'),n=document.querySelector('.nav');
  if(t&&n)t.addEventListener('click',function(){n.classList.toggle('open')});
  // GA4 event tracking for resume and LinkedIn clicks
  document.querySelectorAll('a[href*="resume"],a[href$=".pdf"]').forEach(function(a){
    a.addEventListener('click',function(){if(window.gtag)gtag('event','resume_click',{link:a.getAttribute('href')})});
  });
  document.querySelectorAll('a[href*="linkedin.com"]').forEach(function(a){
    a.addEventListener('click',function(){if(window.gtag)gtag('event','contact_click',{method:'linkedin'})});
  });
});
